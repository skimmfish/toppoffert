<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RespondersController extends Controller
{
    //
}
